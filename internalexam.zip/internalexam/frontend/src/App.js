import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Register from "./pages/Register";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";

function App() {
  return (
    <>
    <Router>
        <nav style={{margin:"10px",padding: "10px"}}>
          <Link to="/register">Register</Link> |{" "}
          <Link to="/login">Login</Link>
        </nav>
        <h1 style={{textAlign: "center", fontFamily: "Times New Roman", color:'#d41616ff'}}>WELCOME TO THE WEBSITE</h1>
        <Routes>
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
