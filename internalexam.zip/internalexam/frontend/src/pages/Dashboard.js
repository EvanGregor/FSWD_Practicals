import React from "react";

function Dashboard() {
  return (
    <div className="container">
      <h2>Dashboard</h2>
      <p>Welcome! You are logged in.</p>
    </div>
  );
}

export default Dashboard;
